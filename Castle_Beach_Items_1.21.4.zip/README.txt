CASTLE BEACH ITEM PACK — Minecraft Java 1.21.4
================================================

Textures:
- zamek.png = the full sand-castle composition from the supplied artwork
- lod.png   = the blue/pink ice pop
- pilka.png = the beach ball

Texture resolution: 32x32 PNG, transparent background, nearest-neighbour pixel art.

Install:
1. Put the ZIP into .minecraft/resourcepacks
2. Enable "Castle Beach Items" in Resource Packs.
3. Give yourself the items with the commands below.

COMMANDS (Java 1.21.4):
Zamek:
  /give @s minecraft:paper[minecraft:item_model="castlepack:zamek"]

Lód:
  /give @s minecraft:snowball[minecraft:item_model="castlepack:lod"]

Piłka:
  /give @s minecraft:slime_ball[minecraft:item_model="castlepack:pilka"]

Optional names:
  /give @s minecraft:paper[minecraft:item_model="castlepack:zamek",minecraft:custom_name='{"text":"Zamek","italic":false}']
  /give @s minecraft:snowball[minecraft:item_model="castlepack:lod",minecraft:custom_name='{"text":"Lód","italic":false}']
  /give @s minecraft:slime_ball[minecraft:item_model="castlepack:pilka",minecraft:custom_name='{"text":"Piłka","italic":false}']

Technical:
- Resource pack format: 46 (Java 1.21.4)
- New 1.21.4 item-model system is used: assets/castlepack/items/*.json
- Models live in assets/castlepack/models/item/
- Textures live in assets/castlepack/textures/item/
